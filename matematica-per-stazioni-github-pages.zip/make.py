from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor
from pypdf import PdfReader,PdfWriter
from pathlib import Path
import json
root=Path(__file__).resolve().parent / 'docs'
stations=[
('Il porto delle trasformazioni','Per 10, 100 e 1.000','Scoprite come cambia il valore delle cifre.',[
('1. Calcolate e confrontate','4,37 x 10 = ______        0,608 x 100 = ______\n2,045 x 1.000 = ______    58,2 : 10 = ______\n436,7 : 100 = ______      72 : 1.000 = ______'),
('2. Trovate il numero mancante','3,48 x ______ = 348\n56 : ______ = 0,056\n______ x 100 = 7,2\n______ : 10 = 0,305'),
('3. Spiegate con un esempio','Che cosa succede al valore della cifra 4 in 4,37 x 100?\nUsate una tabella posizionale o un disegno.'),
('Sfida facoltativa','Partite da 0,42: moltiplicate per 1.000 e dividete per 100.\nQuale unica operazione produce lo stesso risultato?')]),
('L’officina dei calcoli','Operazioni miste','Prima stimate, poi calcolate e confrontate.',[
('1. Un calcolo per ciascuno','A. 18,75 + 6,8 = ______     B. 40 - 12,65 = ______\nC. 3,24 x 5 = ______        D. 18,6 : 3 = ______\nScrivete i calcoli in colonna sul quaderno.'),
('2. Scegliete il primo passo','6,4 + 2,35 x 10 = __________________\n(15,8 - 3,8) : 100 = __________________\n24 : 4 + 1,25 = __________________\nSpiegate quale operazione eseguite per prima.'),
('3. Controllate con la stima','29,8 + 10,3: il risultato e piu vicino a 4, 40 o 400?\nMotivate e poi trovate il risultato esatto.'),
('Sfida facoltativa','Inserite le parentesi per ottenere 50:\n2 + 3 x 10 = 50')]),
('Il mercato dei problemi','Problemi a piu passaggi','Leggete, scegliete i dati e spiegate le operazioni.',[
('1. In cartoleria','Il maestro compra 10 quaderni da 1,35 euro ciascuno\ne una confezione di pennarelli da 8,50 euro.\nPaga con 30 euro. Quanto riceve di resto?\nOperazioni: _______________________________________\nRisposta: _________________________________________'),
('2. Acqua per la festa','Ci sono 24 bottiglie da 1,5 litri. Tutta l’acqua viene\nversata in caraffe da 2 litri. Quante caraffe si riempiono?\nOperazioni: _______________________________________\nRisposta: _________________________________________'),
('3. Spiegate il vostro ragionamento','Rappresentate uno dei problemi con uno schema.\nCome potete verificare che la risposta sia ragionevole?'),
('Sfida facoltativa','Le stesse bottiglie riempiono caraffe da 1,2 litri.\nQuante? Affrontate la sfida se conoscete gia il procedimento.')]),
('Il cantiere dei numeri','Scomposizioni','Ogni cifra ha un posto e un valore.',[
('1. Smontate i numeri','Esempio: 35,407 = 30 + 5 + 0,4 + 0,007\n8,062 = __________________________________________\n120,305 = ________________________________________\n40,009 = _________________________________________'),
('2. Ricostruite','4 decine + 2 unita + 6 centesimi = __________\n7 unita + 3 decimi + 9 millesimi = __________\n2 centinaia + 5 decimi + 1 millesimo = __________'),
('3. Cercate il valore','Nel numero 52,607 quanto vale la cifra 6? __________\nQuanto vale la cifra 7? __________\nPerche lo zero tra 6 e 7 e importante?'),
('Sfida facoltativa','Con 2, 0, 5 e 8, una volta ciascuna, costruite il numero\nmaggiore e il minore con due cifre prima e due dopo\nla virgola. La prima cifra non puo essere zero.')]),
('L’agenzia degli investigatori','Caccia all’errore','Non basta correggere: spiegate il perche.',[
('1. Vero o falso? Correggete se serve','A. 4,56 x 100 = 45,6     V / F  Correzione: __________\nB. 7,2 : 1.000 = 0,0072  V / F  Correzione: __________\nC. 3,08 > 3,8            V / F  Correzione: __________\nD. 6,045 = 6 + 0,4 + 0,005  V / F  __________________'),
('2. Convincete un compagno','Scegliete due errori del punto 1 e spiegateli usando\nil valore delle cifre o un calcolo di controllo.\n__________________________________________________\n__________________________________________________'),
('3. Discutete','"Moltiplicando un numero positivo per 10 si ottiene\nsempre un numero maggiore." Vero o falso? Perche?\nChe cosa succede invece se il numero e zero?'),
('Sfida facoltativa','Inventate un’uguaglianza sbagliata. Sul quaderno\nscrivete la correzione e una spiegazione convincente.')])]
colors=['#087f8c','#d56632','#99702a','#5265b5','#8a5393']
def pdf(path,title,subtitle,blocks,tag='SCHEDA DI GRUPPO',group=True):
 c=canvas.Canvas(str(path),pagesize=(595.28,841.89)); c.setTitle(title)
 c.setFillColor(HexColor('#142d39'));c.rect(0,730,596,112,fill=1,stroke=0)
 c.setFillColor(HexColor('#bde9d7'));c.setFont('Helvetica-Bold',10);c.drawString(40,808,tag)
 c.setFillColorRGB(1,1,1);c.setFont('Helvetica-Bold',21);c.drawString(40,776,title)
 c.setFont('Helvetica',11);c.drawString(40,752,subtitle)
 c.setFillColor(HexColor('#142d39'));c.setFont('Helvetica',10)
 c.drawString(40,706,'Gruppo: __________  Nomi: ________________________________________' if group else 'Maestro Maurizio | Classe quinta')
 y=675
 for heading,body in blocks:
  c.setFillColor(HexColor('#087f8c'));c.setFont('Helvetica-Bold',12);c.drawString(40,y,heading);y-=23
  c.setFillColor(HexColor('#142d39'));c.setFont('Helvetica',11)
  for line in body.split('\n'):c.drawString(40,y,line);y-=19
  y-=20
 assert y>45,(title,y)
 c.setFont('Helvetica',9);c.setFillColor(HexColor('#526776'));c.drawString(40,30,'Le cinque isole della matematica | Classe quinta | Maestro Maurizio');c.save()
for i,(title,sub,desc,blocks) in enumerate(stations):
 pdf(root/'materiali'/f'stazione-{i+1}.pdf',title,sub+' | 12 minuti',blocks,tag=f'STAZIONE {i+1} / 5')
pdf(root/'materiali/guida-docente.pdf','La regia del percorso','Preparazione, rotazioni e osservazione',[
('Prima di iniziare','Preparate le isole e chiamate i gruppi A, B, C, D, E.\nStampate 5 copie di ogni scheda: una per ogni gruppo in transito.\nServono matite, gomme, fogli quadrettati e tabelle posizionali.'),
('Gli incarichi','Lettore: legge la consegna. Scrivano: registra le risposte.\nCustode del tempo: controlla il ritmo. Portavoce: spiega.\nCambiate incarichi a ogni turno; tutti partecipano ai calcoli.'),
('Cinque turni da 12 minuti','Turno      Gruppo A   Gruppo B   Gruppo C   Gruppo D   Gruppo E\n1                 1                 2                 3                 4                 5\n2                 2                 3                 4                 5                 1\n3                 3                 4                 5                 1                 2\n4                 4                 5                 1                 2                 3\n5                 5                 1                 2                 3                 4'),
('Tempi e osservazione','5 minuti iniziali + 60 di lavoro + 4 cambi da 1 minuto\n+ 8 minuti finali = 77 minuti. Possibile dividere in due lezioni.\nOsservate soprattutto la stazione 5. Le sfide sono facoltative.\nAnnotate: autonomia, valore posizionale, calcolo e spiegazione.')],group=False,tag='GUIDA DOCENTE')
pdf(root/'materiali/passaporto.pdf','Il mio passaporto','Una copia per ogni alunno',[
('Nome e gruppo','Nome: __________________________  Gruppo: __________'),
('Dopo ogni isola, scegli e scrivi','1. Trasformazioni: una cosa che ho capito __________________\n______________________________________________________\n2. Calcoli: un procedimento che so spiegare _________________\n______________________________________________________\n3. Problemi: l’operazione che ho scelto e perche ______________\n______________________________________________________\n4. Scomposizioni: una cifra e il suo valore __________________\n______________________________________________________\n5. Errori: una correzione che ho capito ______________________\n______________________________________________________'),
('Biglietto finale - lavora da solo, 3 minuti','4,08 x 100 = __________     63,5 : 1.000 = __________\n7,206 = ______________________________________________\nCorreggi e spiega: 2,4 : 10 = 24\n______________________________________________________'),
('Come e andata?','Cerchia: ho lavorato da solo / con un aiuto / con molti aiuti.\nVorrei esercitarmi ancora su: ____________________________')],group=False,tag='SCHEDA INDIVIDUALE')
pdf(root/'materiali/soluzioni.pdf','Soluzioni e spiegazioni','Da conservare separatamente dalle schede alunni',[
('1. Trasformazioni','43,7; 60,8; 2.045; 5,82; 4,367; 0,072.\nMancanti: 100; 1.000; 0,072; 3,05.\nIl 4 passa dalle unita alle centinaia: vale 400. Sfida: x 10, esito 4,2.'),
('2. Calcoli','25,55; 27,35; 16,2; 6,2. Espressioni: 29,9; 0,12; 7,25.\nStima: 40. Risultato esatto: 40,1. Sfida: (2 + 3) x 10 = 50.'),
('3. Problemi','Cartoleria: 10 x 1,35 = 13,50; + 8,50 = 22; 30 - 22 = 8 euro.\nAcqua: 24 x 1,5 = 36 litri; 36 : 2 = 18 caraffe.\nSfida: 36 : 1,2 = 30 caraffe.'),
('4. Scomposizioni','8 + 0,06 + 0,002; 100 + 20 + 0,3 + 0,005; 40 + 0,009.\n42,06; 7,309; 200,501. Il 6 vale 0,6; il 7 vale 0,007.\nLo zero occupa il posto dei centesimi. Sfida: 85,20 e 20,58.'),
('5. Errori e biglietto finale','A falso: 456. B vero. C falso: 3,08 < 3,8.\nD falso: 6,045 = 6 + 0,04 + 0,005.\nPer un positivo, x 10 aumenta il numero; 0 x 10 = 0.\nBiglietto: 408; 0,0635; 7 + 0,2 + 0,006; 2,4 : 10 = 0,24.')],group=False,tag='RISERVATO AL DOCENTE')
w=PdfWriter()
for f in ['guida-docente.pdf']+[f'stazione-{i}.pdf' for i in range(1,6)]+['passaporto.pdf','soluzioni.pdf']:w.append(str(root/'materiali'/f))
with open(root/'materiali/kit-completo.pdf','wb') as f:w.write(f)
(root/'data.json').write_text(json.dumps([{'title':a,'subtitle':b,'description':c,'color':colors[i]} for i,(a,b,c,d) in enumerate(stations)],ensure_ascii=False))
print('PDF creati, kit 8 pagine')
